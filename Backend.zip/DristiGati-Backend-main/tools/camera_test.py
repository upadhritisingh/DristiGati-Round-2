"""Print camera status; run with the backend's configured URL."""
from app import app
print(app.extensions['camera'].status())
