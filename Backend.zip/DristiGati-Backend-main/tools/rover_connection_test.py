"""Check configured rover adapter without claiming physical hardware."""
from app import app
r=app.extensions['rover']; print(r.status()); print('SIMULATED' if app.extensions['config'].SIMULATED_ROVER else 'PHYSICAL adapter configured')
