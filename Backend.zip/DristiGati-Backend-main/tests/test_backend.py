import time
from types import SimpleNamespace
from app import create_app
from services.event_service import EventService
from services.mission_service import MissionManager
from services.rover_service import SimulatedRoverAdapter
class C:
 SECRET_KEY='x'; CORS_ORIGINS='*'; SIMULATED_ROVER=True; CAMERA_STREAM_URL=''; CAMERA_STALE_SECONDS=5; CAMERA_RECONNECT_SECONDS=1; CAMERA_TIMEOUT_SECONDS=1; YOLO_MODEL='missing.pt'; YOLO_CONFIDENCE=.45; YOLO_IMAGE_SIZE=320; INFERENCE_FREQUENCY=1; PERSON_DETECTION_COOLDOWN_SECONDS=.05; OBSTACLE_TARGET_CLASSES=['box']; OBSTACLE_CONFIDENCE=.4; OBSTACLE_PERSISTENCE=2; FORWARD_PATH_MIN=.2; FORWARD_PATH_MAX=.8; LOG_LEVEL='INFO'
def manager():
 class E:
  def emit(self,*a):pass
 return MissionManager(C,SimulatedRoverAdapter(),E())
def test_health():
 app,_=create_app(C); r=app.test_client().get('/api/health'); assert r.status_code==200 and r.json['success']
def test_start_stop_resume_and_cooldown():
 m=manager(); assert m.start()['state']=='SCANNING'; m.stop(); assert m.status()['operator_paused']; m.resume(); assert m.status()['cooldown']['active']
def test_person_dedup_ack_and_resume():
 m=manager(); m.start(); e=m.person_detected(.9); assert e; assert m.person_detected(.9) is e; m.acknowledge(e.event_id); assert m.resume()['state']=='SCANNING'
def test_safety_priority():
 m=manager(); m.rover.cliff_sensor='DETECTED';
 try:m.start(); assert False
 except ValueError as e:assert 'SAFETY_BLOCKED' in str(e)
def test_obstacle_does_not_stop():
 from services.obstacle_service import ObstacleService
 class E:
  def emit(self,*a):pass
 o=ObstacleService(C,E()); o.observe('box',.9); o.observe('box',.9); assert o.current['status']=='VERIFIED'
