import os
from dataclasses import dataclass, field
from dotenv import load_dotenv
load_dotenv()
def b(k,d=False): return os.getenv(k,str(d)).lower() in ('1','true','yes','on')
def f(k,d):
 try:return float(os.getenv(k,d))
 except:return d
def i(k,d):
 try:return int(os.getenv(k,d))
 except:return d
@dataclass
class Config:
 SECRET_KEY:str=os.getenv('SECRET_KEY','dristigati-dev')
 HOST:str=os.getenv('FLASK_HOST','127.0.0.1'); PORT:int=i('FLASK_PORT',5000)
 CAMERA_STREAM_URL:str=os.getenv('CAMERA_STREAM_URL',''); CAMERA_STALE_SECONDS:float=f('CAMERA_STALE_SECONDS',5)
 CAMERA_RECONNECT_SECONDS:float=f('CAMERA_RECONNECT_SECONDS',2); CAMERA_TIMEOUT_SECONDS:float=f('CAMERA_TIMEOUT_SECONDS',5)
 YOLO_MODEL:str=os.getenv('YOLO_MODEL','yolo11n.pt'); YOLO_CONFIDENCE:float=f('YOLO_CONFIDENCE',.45); YOLO_IMAGE_SIZE:int=i('YOLO_IMAGE_SIZE',320)
 INFERENCE_FREQUENCY:float=f('INFERENCE_FREQUENCY',2); PERSON_DETECTION_COOLDOWN_SECONDS:float=f('PERSON_DETECTION_COOLDOWN_SECONDS',10)
 OBSTACLE_TARGET_CLASSES:list=field(default_factory=lambda:[x.strip().lower() for x in os.getenv('OBSTACLE_TARGET_CLASSES','backpack,bag,suitcase,chair,couch,table,bench,box').split(',') if x.strip()])
 OBSTACLE_CONFIDENCE:float=f('OBSTACLE_CONFIDENCE',.45); OBSTACLE_PERSISTENCE:int=i('OBSTACLE_PERSISTENCE',3); FORWARD_PATH_MIN:float=f('FORWARD_PATH_MIN',.2); FORWARD_PATH_MAX:float=f('FORWARD_PATH_MAX',.8)
 ROVER_BASE_URL:str=os.getenv('ROVER_BASE_URL',''); ROVER_STATUS_URL:str=os.getenv('ROVER_STATUS_URL',''); ROVER_COMMAND_URL:str=os.getenv('ROVER_COMMAND_URL',''); ROVER_HEARTBEAT_TIMEOUT_SECONDS:float=f('ROVER_HEARTBEAT_TIMEOUT_SECONDS',3)
 CORS_ORIGINS:str=os.getenv('CORS_ORIGINS','*'); SIMULATED_ROVER:bool=b('SIMULATED_ROVER',True); LOG_LEVEL:str=os.getenv('LOG_LEVEL','INFO')
 def validate(self):
  if not 0 < self.YOLO_CONFIDENCE <= 1: raise ValueError('YOLO_CONFIDENCE must be between 0 and 1')
  if self.OBSTACLE_PERSISTENCE<1: raise ValueError('OBSTACLE_PERSISTENCE must be >= 1')
config=Config(); config.validate()
