**# Dṛṣṭigati Backend**

A modular Flask + Flask-SocketIO backend for a vision-assisted rover. The laptop owns camera capture, optional Ultralytics YOLO inference, mission policy, and the dashboard API. The ESP32 controller remains the independent authority for motors, cliff/obstacle sensors, and its heartbeat watchdog.

**## Quick start (Windows / VS Code)**

\`\`\`powershell
py -3.11 -m venv .venv
.\\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
python app.py
\`\`\`

The default is deliberately **\*\*SIMULATED_ROVER=true\*\*** and no camera URL, so it runs without hardware. Set \`CAMERA_STREAM_URL\` to the complete MJPEG URL exposed by the ESP32-CAM firmware (do not assume an IP or path). Set \`SIMULATED_ROVER=false\`, \`ROVER_STATUS_URL\`, and \`ROVER_COMMAND_URL\` only after implementing the documented HTTP protocol on the controller. Install \`ultralytics\` and place the configured \`.pt\` weights in the project directory to enable real inference. Missing weights are reported in \`/api/detections/config\`; they are not downloaded or treated as a clear scene.

Run tests with \`pytest -q\`. Start with \`python app.py\`; health is \`GET [http://127.0.0.1:5000/api/health](http://127.0.0.1:5000/api/health)\`. Tools: \`python tools/camera_test.py\` and \`python tools/rover_connection_test.py\`.

**## Architecture and safety**

\`CameraService\` owns one bounded latest-frame buffer and reconnect loop. \`DetectionService\` is optional and starts only when weights and Ultralytics are available. \`MissionManager\` is the sole state authority. A person event requests STOP once, blocks duplicate events until acknowledgement, and starts a configurable time cooldown on accepted RESUME. Cooldown suppresses only automatic person stops; manual STOP, physical sensor faults, controller faults, and communication watchdog behavior always win. Camera obstacle warnings are candidate/verified operator assistance only and never call a rover motor command.

States are \`IDLE\`, \`SCANNING\`, \`PERSON_DETECTED\`, \`AWAITING_CONFIRMATION\`, \`RESUMING\`, \`PAUSED\`, \`SAFETY_STOP\`, \`EMERGENCY_STOP\`, and \`ERROR\`; invalid transitions return structured errors. Unknown or unavailable physical sensor values are not safe. The initial cooldown cannot identify individuals: a different person seen during the window is also suppressed.

**## Hardware protocol expectation**

The real controller should expose \`GET ROVER_STATUS_URL\` returning JSON containing \`connected\`, \`motor_state\`, \`obstacle_sensor\`, \`cliff_sensor\`, \`active_safety_faults\`, and heartbeat information, and \`POST ROVER_COMMAND_URL\` accepting \`{"command":"START|STOP|RESUME"}\` and returning acknowledgement plus confirmed state. The controller must independently stop on faults or heartbeat expiry. The backend has not been tested against physical hardware.

See [FRONTEND_INTEGRATION.md]\(FRONTEND_INTEGRATION.md) for the complete endpoint/event contract and React example.