from dataclasses import dataclass,asdict
from datetime import datetime,timezone
import uuid
def now(): return datetime.now(timezone.utc).isoformat()
@dataclass
class DetectionEvent:
 object_class:str; confidence:float; mission_state:str; status:str='ACTIVE'; acknowledged:bool=False; event_id:str=None; timestamp:str=None
 def __post_init__(self): self.event_id=self.event_id or str(uuid.uuid4()); self.timestamp=self.timestamp or now()
 def public(self): return asdict(self)
