# Frontend integration contract

Base URL is `http://127.0.0.1:5000`; REST paths are under `/api`; connect Socket.IO to the same origin with polling/websocket transports. Configure backend `CORS_ORIGINS=http://localhost:3000`. Every JSON REST success is `{success:true,data,timestamp}`; errors are `{success:false,error:{code,message},timestamp}`. Coordinates, GPS, and bounding boxes are intentionally never returned.

## REST endpoints

| Method | Path | Body | Purpose |
|---|---|---|---|
| GET | `/api/health` | none | Liveness |
| GET | `/api/system/status` | none | Camera, model, rover, mission aggregate |
| GET | `/api/system/capabilities` | none | Features and simulated/hardware flags |
| GET | `/api/camera/status` | none | Connectivity, FPS, dimensions, staleness |
| GET | `/api/camera/stream` | none | Raw multipart MJPEG `<img>` source |
| GET | `/api/camera/annotated-stream` | none | Annotated MJPEG `<img>` source |
| GET | `/api/camera/snapshot` | none | Latest JPEG or 503 |
| GET | `/api/mission/status` | none | Authoritative state and safety |
| GET | `/api/mission/history` | none | Mission event history |
| POST | `/api/mission/start` | `{}` | IDLE + safe rover only |
| POST | `/api/mission/stop` | `{}` | Immediate manual pause; always allowed if command works |
| POST | `/api/mission/resume` | `{}` | Requires acknowledged person event, connection, and safe sensors |
| POST | `/api/detections/acknowledge` | `{"event_id":"..."}` | Acknowledge exactly current person event |
| GET | `/api/detections/current` | none | Current person event or null |
| GET | `/api/detections/history` | none | Recent detection events |
| GET/POST | `/api/detections/config` | none / settings | Inspect config; model-path settings require restart |
| GET/POST | `/api/obstacles/config` | none / settings | Inspect obstacle criteria |
| GET | `/api/obstacles/current` | none | Latest candidate/warning |
| GET | `/api/obstacles/history` | none | Recent warnings |
| GET | `/api/rover/status` | none | Explicit SIMULATED or PHYSICAL telemetry |

Errors include `INVALID_STATE_TRANSITION`, `PERSON_EVENT_NOT_ACKNOWLEDGED`, `STALE_EVENT`, `SAFETY_BLOCKED`, `ROVER_DISCONNECTED`, and `CAMERA_UNAVAILABLE` where applicable.

## Socket.IO events

Server events use the same object payloads returned by REST. `connection_status` and `camera_status` report connectivity; `mission_state_changed` reports mission status; `person_detected` and `person_event_acknowledged` carry `{event_id,object_class,confidence,timestamp,status,acknowledged,mission_state}`; `person_cooldown_started`/`person_cooldown_expired` carry cooldown seconds; `obstacle_candidate`/`obstacle_warning_verified` carry `{event_id,object_class,confidence,timestamp,status,verification_reason,warning}`; `rover_status` and `safety_status` carry rover telemetry; `command_acknowledged` reports requested/acknowledged/confirmed state; `system_error` carries `{code,message}`. On reconnect always GET `/api/system/status`.

## React sketch

```jsx
import {io} from "socket.io-client";
const base="http://127.0.0.1:5000";
const socket=io(base,{transports:["polling","websocket"]});
const state=await fetch(`${base}/api/mission/status`).then(r=>r.json());
socket.on("person_detected", e=>console.log("STOP",e));
socket.on("obstacle_warning_verified", e=>console.warn(e.warning));
const stop=()=>fetch(`${base}/api/mission/stop`,{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
const acknowledge=id=>fetch(`${base}/api/detections/acknowledge`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({event_id:id})});
const resume=()=>fetch(`${base}/api/mission/resume`,{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(async r=>{if(!r.ok) throw await r.json();});
// <img src={`${base}/api/camera/annotated-stream`} onError={/* show fallback */} />
socket.on("connect",()=>fetch(`${base}/api/system/status`));
```

The frontend displays manual pause, person stop, physical sensor stop, emergency stop, and communication/model errors distinctly from the backend state. The cooldown begins only after accepted RESUME and is authoritative; the UI displays the reported remaining seconds and never resumes automatically.
