import time,logging,cv2
from flask import Flask, jsonify, Response, request
from flask_cors import CORS
from flask_socketio import SocketIO
from config import config
from services.event_service import EventService
from services.rover_service import SimulatedRoverAdapter,HttpRoverAdapter,RoverError
from services.camera_service import CameraService
from services.obstacle_service import ObstacleService
from services.mission_service import MissionManager
from services.detection_service import DetectionService
from utils.logging_config import configure
configure(config.LOG_LEVEL)
def create_app(test_config=None):
 c=test_config or config; app=Flask(__name__); app.config['SECRET_KEY']=c.SECRET_KEY; CORS(app,origins=c.CORS_ORIGINS); sio=SocketIO(app,cors_allowed_origins=c.CORS_ORIGINS,async_mode='threading'); events=EventService(sio); rover=SimulatedRoverAdapter() if c.SIMULATED_ROVER else HttpRoverAdapter(c); camera=CameraService(c); obstacles=ObstacleService(c,events); mission=MissionManager(c,rover,events); detection=DetectionService(c,camera,mission,obstacles,events); app.extensions.update(config=c,socketio=sio,rover=rover,camera=camera,obstacles=obstacles,mission=mission,detection=detection); camera.start(); detection.load_model(); detection.start()
 def ok(data,status=200):return jsonify(success=True,data=data,timestamp=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),status
 def err(e,status=400):
  msg=str(e); code,msg=(msg.split(':',1)+[msg])[:2] if ':' in msg else ('REQUEST_FAILED',msg); return jsonify(success=False,error={'code':code,'message':msg.strip()},timestamp=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),status
 @app.errorhandler(Exception)
 def unexpected(e): logging.exception('request failed'); return err('INTERNAL_ERROR: request could not be completed',500)
 @app.get('/api/health')
 def health():return ok({'status':'ok','service':'dristigati-backend'})
 @app.get('/api/system/status')
 def sysstatus():return ok({'camera':camera.status(),'detection':detection.config(),'rover':rover.status(),'mission':mission.status()})
 @app.get('/api/system/capabilities')
 def caps():return ok({'simulated_rover':c.SIMULATED_ROVER,'camera_configured':bool(c.CAMERA_STREAM_URL),'yolo_available':detection.model is not None,'hardware_tested':False})
 @app.get('/api/camera/status')
 def camstatus():return ok(camera.status())
 def stream(annotated=False):
  def gen():
   while True:
    f=camera.get_frame(annotated)
    if f is not None:
     _,b=cv2.imencode('.jpg',f); yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n'+b.tobytes()+b'\r\n'
    time.sleep(.05)
  return Response(gen(),mimetype='multipart/x-mixed-replace; boundary=frame')
 @app.get('/api/camera/stream')
 def raw_stream(): return stream(False)
 @app.get('/api/camera/annotated-stream')
 def annotated_stream(): return stream(True)
 @app.get('/api/camera/snapshot')
 def snapshot():
  f=camera.get_frame(True)
  if f is None:return err('CAMERA_UNAVAILABLE: no valid frame available',503)
  _,b=cv2.imencode('.jpg',f); return Response(b.tobytes(),mimetype='image/jpeg')
 @app.get('/api/mission/status')
 def ms():return ok(mission.status())
 @app.get('/api/mission/history')
 def mh():return ok(mission.history[:int(request.args.get('limit',50))])
 def command(fn):
  try:return ok(fn())
  except (ValueError,RoverError) as e:return err(e,409)
 @app.post('/api/mission/start')
 def start_route(): return command(mission.start)
 @app.post('/api/mission/stop')
 def stop_route(): return command(mission.stop)
 @app.post('/api/mission/resume')
 def resume_route(): return command(mission.resume)
 @app.post('/api/detections/acknowledge')
 def ack():
  try:return ok(mission.acknowledge((request.get_json(silent=True) or {}).get('event_id')))
  except ValueError as e:return err(e,409)
 @app.get('/api/detections/current')
 def dc():return ok(mission.status()['current_detection'])
 @app.get('/api/detections/history')
 def dh():return ok([x.public() for x in detection.history[:50]])
 @app.get('/api/detections/config')
 def dcfg():return ok(detection.config())
 @app.post('/api/detections/config')
 def dcfgpost():return ok({'message':'Runtime config changes are limited; restart for model path changes','config':detection.config()})
 @app.get('/api/obstacles/current')
 def oc():return ok(obstacles.current)
 @app.get('/api/obstacles/history')
 def oh():return ok(obstacles.history[:50])
 @app.get('/api/obstacles/config')
 def og():return ok(obstacles.config)
 @app.post('/api/obstacles/config')
 def op():return ok(obstacles.config)
 @app.get('/api/rover/status')
 def rs():return ok(rover.status())
 return app,sio
app,socketio=create_app()
if __name__=='__main__':socketio.run(app,host=config.HOST,port=config.PORT,allow_unsafe_werkzeug=True)
