import time
import threading
import requests


class RoverError(Exception):
    pass


class RoverAdapter:
    def status(self):
        raise NotImplementedError

    def command(self, action):
        raise NotImplementedError


class SimulatedRoverAdapter(RoverAdapter):
    def __init__(self):
        self.lock = threading.RLock()
        self.motor_state = "STOPPED"
        self.connected = True
        self.obstacle_sensor = "SAFE"
        self.cliff_sensor = "SAFE"
        self.last_heartbeat = time.time()
        self.faults = []

    def status(self):
        with self.lock:
            return {
                "mode": "SIMULATED",
                "connected": self.connected,
                "motor_state": self.motor_state,
                "obstacle_sensor": self.obstacle_sensor,
                "cliff_sensor": self.cliff_sensor,
                "last_heartbeat": self.last_heartbeat,
                "active_safety_faults": list(self.faults),
                "last_confirmed_controller_state": self.motor_state,
            }

    def command(self, action):
        with self.lock:
            if not self.connected:
                raise RoverError("Simulated rover is disconnected")

            if action in ("START", "RESUME") and (
                self.obstacle_sensor != "SAFE"
                or self.cliff_sensor != "SAFE"
                or self.faults
            ):
                raise RoverError("Safety conditions do not permit movement")

            self.motor_state = (
                "MOVING" if action in ("START", "RESUME") else "STOPPED"
            )
            self.last_heartbeat = time.time()

            return {
                "requested": action,
                "acknowledged": True,
                "confirmed_state": self.motor_state,
                "mode": "SIMULATED",
            }


class HttpRoverAdapter(RoverAdapter):
    def __init__(self, config):
        self.c = config

    def status(self):
        url = self.c.ROVER_STATUS_URL

        if not url:
            return {
                "mode": "PHYSICAL",
                "connected": False,
                "configured": False,
                "motor_state": "UNKNOWN",
                "obstacle_sensor": "UNKNOWN",
                "cliff_sensor": "UNKNOWN",
                "last_confirmed_controller_state": "UNKNOWN",
                "error": "ROVER_STATUS_URL is not configured",
            }

        try:
            response = requests.get(
                url,
                timeout=self.c.ROVER_HEARTBEAT_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
            data = response.json()

            if not isinstance(data, dict):
                raise RoverError("Rover status response must be a JSON object")

            # Preserve the controller's actual readings.
            data["mode"] = "PHYSICAL"
            data["configured"] = True
            return data

        except (requests.RequestException, ValueError, RoverError) as exc:
            return {
                "mode": "PHYSICAL",
                "connected": False,
                "configured": True,
                "motor_state": "UNKNOWN",
                "obstacle_sensor": "UNKNOWN",
                "cliff_sensor": "UNKNOWN",
                "last_confirmed_controller_state": "UNKNOWN",
                "error": str(exc),
            }

    def command(self, action):
        if not self.c.ROVER_COMMAND_URL:
            raise RoverError(
                "ROVER_COMMAND_URL is not configured; command not sent"
            )

        if action in ("START", "RESUME"):
            current = self.status()

            if not current.get("connected"):
                raise RoverError(
                    "Rover is not connected; movement command rejected"
                )

            if (
                current.get("obstacle_sensor") != "SAFE"
                or current.get("cliff_sensor") != "SAFE"
                or current.get("active_safety_faults") is None
                or current.get("active_safety_faults") != []
            ):
                raise RoverError(
                    "Safety status is not confirmed clear; "
                    "movement command rejected"
                )

        try:
            response = requests.post(
                self.c.ROVER_COMMAND_URL,
                json={"command": action},
                timeout=self.c.ROVER_HEARTBEAT_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
            result = response.json()

            if not isinstance(result, dict):
                raise RoverError("Rover command response must be a JSON object")

            return result

        except (requests.RequestException, ValueError) as exc:
            raise RoverError(f"Rover command failed: {exc}") from exc