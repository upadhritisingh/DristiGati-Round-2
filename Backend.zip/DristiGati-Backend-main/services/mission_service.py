import time,threading
from models.mission_state import MissionState
from models.detection_event import DetectionEvent
class MissionManager:
 def __init__(self,c,rover,events): self.c=c; self.rover=rover; self.events=events; self.lock=threading.RLock(); self.state=MissionState.IDLE; self.operator_paused=False; self.current_event=None; self.cooldown_until=0; self.history=[]; self.safety={}
 def _record(self,kind,detail=None):
  e={'event_id':__import__('uuid').uuid4().hex,'event_type':kind,'timestamp':time.time(),'state':self.state.value,'detail':detail}; self.history.insert(0,e); self.history=self.history[:100]; self.events.emit('mission_state_changed',self.status()); return e
 def _refresh(self): self.safety=self.rover.status()
 def status(self):
  with self.lock:
   self._refresh(); rem=max(0,self.cooldown_until-time.time()); return {'state':self.state.value,'current_detection':None if not self.current_event else self.current_event.public(),'operator_paused':self.operator_paused,'cooldown':{'active':rem>0,'remaining_seconds':round(rem,2)},'rover':self.safety,'safety_status':self.safety}
 def start(self):
  with self.lock:
   if self.state!=MissionState.IDLE: raise ValueError('INVALID_STATE_TRANSITION: mission can only start from IDLE')
   self._refresh(); self._check_safe(); self.rover.command('START'); self.state=MissionState.SCANNING; self.operator_paused=False; return self.status()
 def stop(self):
  with self.lock:self.rover.command('STOP'); self.operator_paused=True; self.state=MissionState.PAUSED; self._record('MANUAL_STOP'); return self.status()
 def person_detected(self,confidence):
  with self.lock:
   if self.current_event and not self.current_event.acknowledged:return self.current_event
   if time.time()<self.cooldown_until:return None
   self.current_event=DetectionEvent('person',confidence,self.state.value); self.state=MissionState.PERSON_DETECTED; self.rover.command('STOP'); self.events.emit('person_detected',self.current_event.public()); self._record('PERSON_DETECTED'); return self.current_event
 def acknowledge(self,event_id):
  with self.lock:
   if not self.current_event or self.current_event.event_id!=event_id: raise ValueError('STALE_EVENT: event ID is not current')
   self.current_event.acknowledged=True; self.current_event.status='ACKNOWLEDGED'; self.events.emit('person_event_acknowledged',self.current_event.public()); return self.current_event.public()
 def resume(self):
  with self.lock:
   if self.current_event and not self.current_event.acknowledged: raise ValueError('PERSON_EVENT_NOT_ACKNOWLEDGED: acknowledge the current event first')
   self._refresh(); self._check_safe(); self.rover.command('RESUME'); self.state=MissionState.SCANNING; self.operator_paused=False; self.cooldown_until=time.time()+self.c.PERSON_DETECTION_COOLDOWN_SECONDS; self.events.emit('person_cooldown_started',{'remaining_seconds':self.c.PERSON_DETECTION_COOLDOWN_SECONDS}); return self.status()
 def _check_safe(self):
  if not self.safety.get('connected'):raise ValueError('ROVER_DISCONNECTED: rover is not connected')
  if self.safety.get('obstacle_sensor')!='SAFE' or self.safety.get('cliff_sensor')!='SAFE' or self.safety.get('active_safety_faults'): self.state=MissionState.SAFETY_STOP; raise ValueError('SAFETY_BLOCKED: physical sensors or controller fault prohibit movement')
