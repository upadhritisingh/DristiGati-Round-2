import cv2, threading, time
class CameraService:
 def __init__(self,c): self.c=c; self.lock=threading.RLock(); self.frame=None; self.annotated=None; self.running=False; self.connected=False; self.last_frame_ts=None; self.frames=0; self.started=time.time(); self.error=None; self.thread=None
 def start(self):
  if self.running or not self.c.CAMERA_STREAM_URL:return
  self.running=True; self.thread=threading.Thread(target=self._loop,daemon=True); self.thread.start()
 def _loop(self):
  while self.running:
   cap=cv2.VideoCapture(self.c.CAMERA_STREAM_URL)
   if not cap.isOpened(): self.connected=False; self.error='Unable to open camera stream'; time.sleep(self.c.CAMERA_RECONNECT_SECONDS); continue
   self.connected=True
   while self.running:
    ok,frame=cap.read()
    if not ok: self.connected=False; self.error='Camera frame read failed'; break
    with self.lock:self.frame=frame; self.annotated=frame.copy(); self.last_frame_ts=time.time(); self.frames+=1; self.error=None
   cap.release(); time.sleep(self.c.CAMERA_RECONNECT_SECONDS)
 def status(self):
  with self.lock:
   age=None if self.last_frame_ts is None else time.time()-self.last_frame_ts
   return {'configured':bool(self.c.CAMERA_STREAM_URL),'connected':self.connected,'streaming':self.frame is not None,'actual_fps':round(self.frames/max(time.time()-self.started,1),2),'frame_dimensions':None if self.frame is None else {'width':int(self.frame.shape[1]),'height':int(self.frame.shape[0])},'latest_frame_timestamp':self.last_frame_ts,'stale':age is None or age>self.c.CAMERA_STALE_SECONDS,'error':self.error}
 def get_frame(self,annotated=False):
  with self.lock:
   f=self.annotated if annotated else self.frame
   return None if f is None else f.copy()
 def stop(self): self.running=False
