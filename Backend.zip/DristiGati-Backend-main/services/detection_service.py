import os, threading, time, logging
class DetectionService:
 def __init__(self,c,camera,mission,obstacles,events): self.c=c; self.camera=camera; self.mission=mission; self.obstacles=obstacles; self.events=events; self.model=None; self.error=None; self.running=False; self.thread=None; self.current={'person_present':False,'confidence':None,'last_seen':None,'model_loaded':False,'error':None}; self.history=[]
 def load_model(self):
  if not os.path.exists(self.c.YOLO_MODEL): self.error=f'Model weights not found: {self.c.YOLO_MODEL}'; self.current['error']=self.error; return False
  try:
   from ultralytics import YOLO
   self.model=YOLO(self.c.YOLO_MODEL); self.current['model_loaded']=True; return True
  except Exception as e:self.error=f'YOLO unavailable: {e}'; self.current['error']=self.error; return False
 def start(self):
  if not self.model or self.running:return
  self.running=True; self.thread=threading.Thread(target=self._loop,daemon=True); self.thread.start()
 def _loop(self):
  while self.running:
   f=self.camera.get_frame()
   if f is not None:
    try:
     results=self.model(f,conf=self.c.YOLO_CONFIDENCE,imgsz=self.c.YOLO_IMAGE_SIZE,verbose=False)[0]
     for b in results.boxes:
      cls=results.names[int(b.cls[0])]; conf=float(b.conf[0]);
      if cls.lower()=='person': self.mission.person_detected(conf)
      else:self.obstacles.observe(cls,conf)
    except Exception as e:self.error=f'Inference failed: {e}'; self.current['error']=self.error
   time.sleep(1/max(self.c.INFERENCE_FREQUENCY,.1))
 def stop(self):self.running=False
 def config(self):return {'model':self.c.YOLO_MODEL,'confidence':self.c.YOLO_CONFIDENCE,'image_size':self.c.YOLO_IMAGE_SIZE,'inference_frequency':self.c.INFERENCE_FREQUENCY,'weights_available':os.path.exists(self.c.YOLO_MODEL),'error':self.error}
