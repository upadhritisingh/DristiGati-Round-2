import time,uuid
class ObstacleService:
 def __init__(self,c,events): self.c=c; self.events=events; self.current=None; self.history=[]; self.counts={}; self.config={'target_classes':c.OBSTACLE_TARGET_CLASSES,'confidence_threshold':c.OBSTACLE_CONFIDENCE,'persistence_frames':c.OBSTACLE_PERSISTENCE,'forward_path':{'min':c.FORWARD_PATH_MIN,'max':c.FORWARD_PATH_MAX}}
 def observe(self,cls,confidence,in_forward_path=True):
  if cls.lower() not in self.c.OBSTACLE_TARGET_CLASSES or confidence<self.c.OBSTACLE_CONFIDENCE:return None
  k=cls.lower(); self.counts[k]=self.counts.get(k,0)+1; status='VERIFIED' if self.counts[k]>=self.c.OBSTACLE_PERSISTENCE and in_forward_path else 'CANDIDATE'; e={'event_id':str(uuid.uuid4()),'object_class':k,'confidence':round(float(confidence),3),'timestamp':time.time(),'status':status,'verification_reason':'persistent detection in configured forward path' if status=='VERIFIED' else 'awaiting persistence and forward-path checks','warning':'Possible visual obstacle; operator review required; no motor stop issued.'}
  self.current=e; self.history.insert(0,e); self.history=self.history[:100]; self.events.emit('obstacle_warning_verified' if status=='VERIFIED' else 'obstacle_candidate',e); return e
