class EventService:
 def __init__(self,socketio): self.socketio=socketio
 def emit(self,event,payload): self.socketio.emit(event,payload)
