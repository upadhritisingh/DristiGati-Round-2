def json_body(req):
 d=req.get_json(silent=True)
 if d is None: raise ValueError('INVALID_JSON: request body must be valid JSON')
 return d
